# ai/predict_model.py
import sys
import os
import numpy as np
from tensorflow.keras.models import load_model
from utils.preprocess import preprocess_image

# Add parent directory to path for imports
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Load trained model
model = load_model("model/signature_cnn.h5")

def predict_signature(img_path):
    img = preprocess_image(img_path)
    img = np.expand_dims(img, axis=0)
    pred = model.predict(img)[0]
    print(f"Raw prediction score: {float(pred):.4f}")
    return "✅ Genuine" if pred > 0.5 else "❌ Forged"

# Loop through all images in dataset/genuine
folder_path = "dataset/genuine"
for filename in os.listdir(folder_path):
    if filename.lower().endswith(('.png', '.jpg', '.jpeg')):
        img_path = os.path.join(folder_path, filename)
        print(f"\nTesting: {filename}")
        result = predict_signature(img_path)
        print(f"Prediction result: {result}")
