# utils/preprocess.py

import cv2
import numpy as np

def preprocess_image(img_path):
    """
    Reads an image from disk, converts to grayscale, resizes to 150x220,
    and normalizes pixel values between 0 and 1.
    """
    img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise FileNotFoundError(f"Image not found at: {img_path}")
    img = cv2.resize(img, (220, 150))     # width x height
    img = img / 255.0                     # Normalize to [0,1]
    img = np.expand_dims(img, axis=-1)   # Add channel dimension → (H, W, 1)
    return img
